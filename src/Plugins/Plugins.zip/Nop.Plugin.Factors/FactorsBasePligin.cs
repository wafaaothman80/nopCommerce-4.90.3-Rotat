﻿

using Microsoft.AspNetCore.Routing;
using Nop.Core.Infrastructure;
using Nop.Core;
using Nop.Services.Cms;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Web.Framework.Menu;
using Nop.Services.Customers;
using Nop.Services.Security;
using Nop.Core.Domain.Security;
using Nop.Core.Domain.ScheduleTasks;
using Nop.Services.ScheduleTasks;
using ExCSS;

namespace Nop.Plugin.Factors;

public class FactorsBasePligin : BasePlugin, IAdminMenuPlugin

{

  
    #region Fields
    protected readonly ILocalizationService _localizationService;
    protected readonly ICustomerService _customerService;
    protected readonly IWorkContext _workContext;

    private readonly IWebHelper _webHelper;

    #endregion

    #region Ctor

    public FactorsBasePligin(IPermissionService permissionService, ILocalizationService localizationService, ICustomerService customerService, IWebHelper webHelper, IWorkContext workContext)
    {
        _localizationService = localizationService;
        _customerService = customerService;
      
        _webHelper = webHelper;

        _workContext = workContext;
    }

    public bool HideInWidgetList => throw new NotImplementedException();

   

    #endregion

    #region Methods
   

    /// <summary>
    /// Install the plugin
    /// </summary>
    /// <returns>A task that represents the asynchronous operation</returns>
    public override async Task InstallAsync()
    {
        

        
        await base.InstallAsync();
    }

    public async Task ManageSiteMapAsync(SiteMapNode rootNode)
    {
        var customer = await _workContext.GetCurrentCustomerAsync();
        var CurrentCustomerRoleIds = await _customerService.GetCustomerRoleIdsAsync(customer);
        if (CurrentCustomerRoleIds.Contains(1))
        { 
            SiteMapNode ourPluginsNode = rootNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "CODFactorRoot");
        if (ourPluginsNode == null)
        {
            // Create the root node for our plugin
            ourPluginsNode = new SiteMapNode();
            ourPluginsNode.SystemName = "CODFactorRoot";
            ourPluginsNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.MainMenu");
            ourPluginsNode.Visible = true;
            ourPluginsNode.IconClass = "fa-gears";
            rootNode.ChildNodes.Add(ourPluginsNode);
        }

       
        SiteMapNode codFactorsNode = ourPluginsNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "CODFactors");
        if (codFactorsNode == null)
        {
            codFactorsNode = new SiteMapNode();
            codFactorsNode.SystemName = "CODFactors";
            codFactorsNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.CODFactors");
            codFactorsNode.Visible = true;
            codFactorsNode.Url = "~/Admin/CODFactors/List";
           // codFactorsNode.IconClass = "fa-money";
            ourPluginsNode.ChildNodes.Add(codFactorsNode);
        }

        
        SiteMapNode categoryFactorsNode = ourPluginsNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "CategoryFactors");
        if (categoryFactorsNode == null)
        {
            categoryFactorsNode = new SiteMapNode();
            categoryFactorsNode.SystemName = "CategoryFactors";
            categoryFactorsNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.CategoryFactors");
            categoryFactorsNode.Visible = true;
            categoryFactorsNode.Url = "~/Admin/CategoryFactors/List";
           // categoryFactorsNode.IconClass = "fa-list";
            ourPluginsNode.ChildNodes.Add(categoryFactorsNode);
        }
        SiteMapNode BrandFactorsNode = ourPluginsNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "BrandFactors");
        if (BrandFactorsNode == null)
        {
            BrandFactorsNode = new SiteMapNode();
            BrandFactorsNode.SystemName = "BrandFactors";
            BrandFactorsNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.BrandFactors");
            BrandFactorsNode.Visible = true;
            BrandFactorsNode.Url = "~/Admin/BrandFactors/List";
           // BrandFactorsNode.IconClass = "fa-list";
            ourPluginsNode.ChildNodes.Add(BrandFactorsNode);
        }
        SiteMapNode CustomerTypeNode = ourPluginsNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "CustomerType");
        if (CustomerTypeNode == null)
        {
            CustomerTypeNode = new SiteMapNode();
            CustomerTypeNode.SystemName = "CustomerType";
            CustomerTypeNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.CustomerType");
            CustomerTypeNode.Visible = true;
            CustomerTypeNode.Url = "~/Admin/CustomerType/List";
         //   CustomerTypeNode.IconClass = "fa-list";
            ourPluginsNode.ChildNodes.Add(CustomerTypeNode);
        }

        SiteMapNode FactorsNode = ourPluginsNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "Factors");
        if (FactorsNode == null)
        {
            FactorsNode = new SiteMapNode();
            FactorsNode.SystemName = "CustomerType";
            FactorsNode.Title = await _localizationService.GetResourceAsync("Plugins.Factors.Factors");
            FactorsNode.Visible = true;
            FactorsNode.Url = "~/Admin/Factors/List";
            //   CustomerTypeNode.IconClass = "fa-list";
            ourPluginsNode.ChildNodes.Add(FactorsNode);
        }
        }
    }

    public override string GetConfigurationPageUrl()
    {
        return $"{_webHelper.GetStoreLocation()}Admin/Factors/Configure";
    }

    /// <summary>
    /// Uninstall the plugin
    /// </summary>
    /// <returns>A task that represents the asynchronous operation</returns>
    public override async Task UninstallAsync()
    {
       
       
        await base.UninstallAsync();
    }



 
    
    #endregion
}