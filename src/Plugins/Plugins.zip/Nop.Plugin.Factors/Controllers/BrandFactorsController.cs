﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Factors.Models;
using Nop.Plugin.Factors.Services;
using Nop.Services.Customers;
using Nop.Services.Security;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Mvc.Filters;

namespace Nop.Plugin.Factors.Controllers
{
    [AuthorizeAdmin]
    [Area(AreaNames.ADMIN)]
    [AutoValidateAntiforgeryToken]
    public class BrandFactorsController : BasePluginController
    {
        #region Fields
        private readonly IBrandFactorsService _BrandFactorsService;
        private readonly IPermissionService _permissionService;
        private readonly IBrandFactorsModelFactory _BrandFactorsModelFactory;
        protected readonly IWorkContext _workContext;
        protected readonly ICustomerService _customerService;
        #endregion

        #region Ctor

        public BrandFactorsController(
            IBrandFactorsService BrandFactorsService,
            IPermissionService permissionService,
            IBrandFactorsModelFactory BrandFactorsModelFactory, IWorkContext workContext, ICustomerService customerService)
        {
            _BrandFactorsService = BrandFactorsService;
            _permissionService = permissionService;
            _BrandFactorsModelFactory = BrandFactorsModelFactory;
            _workContext = workContext;
            _customerService = customerService;
        }
        #endregion

        public virtual async Task<IActionResult> List()
        {
            var customer = await _workContext.GetCurrentCustomerAsync();
            var CurrentCustomerRoleIds = await _customerService.GetCustomerRoleIdsAsync(customer);
            if (!CurrentCustomerRoleIds.Contains(1))
                return AccessDeniedView();

            //prepare model
            var model = await _BrandFactorsModelFactory.PrepareBrandFactorsSearchModelAsync(new BrandsFactorsSearchModel());

            return View("~/Plugins/Nop.Plugin.Factors/Views/BrandFactors/List.cshtml", model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> List(BrandsFactorsSearchModel searchModel)
        {
            var customer = await _workContext.GetCurrentCustomerAsync();
            var CurrentCustomerRoleIds = await _customerService.GetCustomerRoleIdsAsync(customer);
            if (!CurrentCustomerRoleIds.Contains(1))
                return await AccessDeniedDataTablesJson();

            //prepare model
            var model = await _BrandFactorsModelFactory.PrepareBrandFactorsListModelAsync(searchModel);

            return Json(model);
        }

        [HttpPost]
        public virtual async Task<IActionResult> UpdateFactor([FromForm] int id, [FromForm] decimal factor)
        {
            try
            {

                if (id <= 0)
                {
                    return Json(new { success = false, message = $"Invalid ID: {id}. ID must be greater than 0." });
                }

                var BrandFactor = await _BrandFactorsService.GetByIdAsync(id);
                if (BrandFactor == null)
                {
                    return Json(new { success = false, message = $"Record with ID {id} not found." });
                }

                BrandFactor.Factor = factor;
                await _BrandFactorsService.UpdateAsync(BrandFactor);

                return Json(new { success = true, message = "Factor updated successfully" });
            }
            catch (System.Exception ex)
            {
                return Json(new { success = false, message = "An error occurred while updating the factor." });
            }
        }

        [HttpPost]
        public virtual async Task<IActionResult> Delete(int id)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePaymentMethods))
                return AccessDeniedView();

            var BrandFactor = await _BrandFactorsService.GetByIdAsync(id);
            if (BrandFactor != null)
            {
                await _BrandFactorsService.DeleteAsync(BrandFactor);
            }

            return RedirectToAction("List");
        }
    }
}