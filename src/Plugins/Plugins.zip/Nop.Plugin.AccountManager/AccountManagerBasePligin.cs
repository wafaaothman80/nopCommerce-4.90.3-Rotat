﻿

using Microsoft.AspNetCore.Routing;
using Nop.Core;
using Nop.Core.Infrastructure;
using Nop.Plugin.AccountManager.Components;
using Nop.Services.Cms;
using Nop.Services.Customers;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Web.Framework.Infrastructure;
using Nop.Web.Framework.Menu;

namespace Nop.Plugin.AccountManager;

public class AccountManagerBasePligin : BasePlugin, IAdminMenuPlugin, IWidgetPlugin
{
    #region Fields
    protected readonly ILocalizationService _localizationService;
    protected readonly ICustomerService _customerService;

    #endregion

    #region Ctor

    public AccountManagerBasePligin(ILocalizationService localizationService, ICustomerService customerService)
    {
        _localizationService = localizationService;
        _customerService = customerService;

    }

 


    #endregion

    #region Methods



    /// <summary>
    /// Install the plugin
    /// </summary>
    /// <returns>A task that represents the asynchronous operation</returns>
    public override async Task InstallAsync()
    {
       

        await base.InstallAsync();
    }

    public async Task ManageSiteMapAsync(SiteMapNode rootNode)
    {
        var workContext = EngineContext.Current.Resolve<IWorkContext>();
        var CurrentCustomer = await EngineContext.Current.Resolve<IWorkContext>().GetCurrentCustomerAsync();


        var CurrentCustomerRoleIds = await _customerService.GetCustomerRoleIdsAsync(CurrentCustomer);
        if (CurrentCustomerRoleIds.Contains(1))
        {




            SiteMapNode ourPluginsNode = rootNode.ChildNodes.FirstOrDefault<SiteMapNode>((SiteMapNode x) => x.SystemName == "OurPlugins");
            if (ourPluginsNode == null)
            {
                // Create the root
                ourPluginsNode = new SiteMapNode();
                ourPluginsNode.SystemName = "Ourplugins";
                ourPluginsNode.Title = await _localizationService.GetResourceAsync("TheRoot.Nop.Plugin.OurPlugins");
                ourPluginsNode.Visible = true;
                ourPluginsNode.IconClass = "fa-dot-circle-o";
                rootNode.ChildNodes.Add(ourPluginsNode);
            }



            SiteMapNode child2 = new SiteMapNode();
            child2.Title = await _localizationService.GetResourceAsync("TheRoot.Nop.Plugin.OurPlugins.AccountManagers");
            child2.Url = "~/Admin/AccountManager/List";
            child2.SystemName = "TheRoot.Nop.Plugin.OurPlugins.AccountManagers";
            child2.Visible = true;
            //child2.IconClass = "fa-genderless";
            child2.RouteValues = new RouteValueDictionary()
                {
                    { "Namespaces", "Nop.Plugin.AccountManager" },
                    { "area", "admin" }
                };

            ourPluginsNode.ChildNodes.Add(child2);
            SiteMapNode child3 = new SiteMapNode();
            child3.Title = await _localizationService.GetResourceAsync("TheRoot.Nop.Plugin.OurPlugins.Rigions");
            child3.Url = "~/Admin/Rigion/List";
            child3.SystemName = "TheRoot.Nop.Plugin.OurPlugins.Rigions";
            child3.Visible = true;
            //child2.IconClass = "fa-genderless";
            child3.RouteValues = new RouteValueDictionary()
                {
                    { "Namespaces", "Nop.Plugin.Rigion" },
                    { "area", "admin" }
                };

            ourPluginsNode.ChildNodes.Add(child3);
        }

        // throw new NotImplementedException();
    }

    /// <summary>
    /// Uninstall the plugin
    /// </summary>
    /// <returns>A task that represents the asynchronous operation</returns>
    public override async Task UninstallAsync()
    {
       

        await base.UninstallAsync();
    }

    public Type GetWidgetViewComponent(string widgetZone)
    {
       
        return typeof(AccountManagerContactViewComponent);
    }

    public bool HideInWidgetList => false;

    public Task<IList<string>> GetWidgetZonesAsync()
    {

        IList<string> zones = new List<string>
            {
                PublicWidgetZones.HomepageTop
            };

        return Task.FromResult(zones);
    }

   


    #endregion
}